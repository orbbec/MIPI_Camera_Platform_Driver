# C++ Sample: 3.advanced.timestamp_tracker

## Overview

Frame rate and timestamp stability are two important performance indicators for cameras.  
We need a tool that can record frame rate and timestamps in order to analyze their stability.

## Features

The tool mainly supports the following features:
1. Load the first connected camera device on the system and start all supported data streams;
2. Capture each frame from the data streams and save frame rate, timestamp, and other information into a CSV file. The CSV files are saved in the `output` directory under the tool’s folder. The filename format is:  
   `{DeviceName}_{DeviceSerial}_{Sensor}_{Resolution}_{FrameRate}fps_{Timestamp}.csv`  
   For example:  
   `Orbbec Gemini 335Lg_CP1S34D0002D_Color_848x480_30fps_20250517164457.csv`
3. Calculate the current frame rate every second and save it to a CSV file. The CSV file is saved in the `output` directory under the tool’s folder. The filename format is:  
   `{DeviceName}_{DeviceSerial}_AverageFrameRate_{Timestamp}.csv`  
   For example:  
   `Orbbec Gemini 335Lg_CP1S34D0002D_AverageFrameRate_20250517164457.csv`
4. Supported devices: Various cameras supported by the OpenOrbbecSDK.

## Usage

### Launch

Double-click the `ob_timestamp_tracker` executable file to start the tool. By default, it will keep running unless the user exits manually.  
Alternatively, run the tool in a terminal and specify the runtime duration (in minutes):  
`./ob_timestamp_tracker -t 10`

### Exit

1. The program exits automatically after capturing the specified number of frames;
2. Or press the `Esc` key in the window, or close the window directly to exit the program.

## Data Analysis

TODO
