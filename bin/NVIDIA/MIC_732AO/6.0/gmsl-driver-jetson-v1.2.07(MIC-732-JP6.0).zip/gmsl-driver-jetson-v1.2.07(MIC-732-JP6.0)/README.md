# ORBBEC camera driver for GMSL

## Install kernel and G335Lg driver to Jetson

on target Jetson Devkit Copy them to the right places:

```
cd gmsl-driver-jetson

# MIC-732 + G335Lg + ADVANTECH MIC-FG-8G Dser board 
sh copy_to_target_agx_orin_mic_fg_8g.sh

```