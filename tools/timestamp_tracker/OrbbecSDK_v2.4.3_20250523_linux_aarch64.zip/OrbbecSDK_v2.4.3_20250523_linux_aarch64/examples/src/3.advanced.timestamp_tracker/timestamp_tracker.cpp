// Copyright (c) Orbbec Inc. All Rights Reserved.
// Licensed under the MIT License.

#include <libobsensor/ObSensor.h>
#include <libobsensor/ObSensor.hpp>
#include "utils.hpp"

#include <mutex>
#include <thread>
#include <fstream>
#include <iostream>
#include <queue>
#include <condition_variable>

#include <algorithm>
#include <iomanip>
#include <ctime>
#include <chrono>
#include <map>
#include <atomic>

#define ESC_KEY 27
std::mutex                                frameMutex;
std::queue<std::shared_ptr<ob::FrameSet>> frameSetQueue;
std::condition_variable                   frameCv;

std::mutex                                imuFrameMutex;
std::queue<std::shared_ptr<ob::FrameSet>> imuFrameSetQueue;
std::condition_variable                   imuFrameCv;

std::ofstream frameRateOutfile;
std::ofstream colorOutfile;
std::ofstream depthOutfile;
std::ofstream leftIrOutfile;
std::ofstream rightIrOutfile;
std::ofstream accelOutfile;
std::ofstream gyroOutfile;

uint64_t colorDiff   = 0;
uint64_t depthDiff   = 0;
uint64_t leftIrDiff  = 0;
uint64_t rightIrDiff = 0;
uint64_t accelDiff   = 0;
uint64_t gyroDiff    = 0;

struct PreFrameTimeStamp {
    bool     first              = true;
    uint64_t frameIndex         = 0;
    uint64_t preGlobalTimeStamp = 0;
    uint64_t preTimeStamp       = 0;
};

int getSampleRate(OBIMUSampleRate rate) {
    switch(rate) {
    case OB_SAMPLE_RATE_25_HZ:
        return 25;
    case OB_SAMPLE_RATE_50_HZ:
        return 50;
    case OB_SAMPLE_RATE_100_HZ:
        return 100;
    case OB_SAMPLE_RATE_200_HZ:
        return 200;
    case OB_SAMPLE_RATE_500_HZ:
        return 500;
    case OB_SAMPLE_RATE_1_KHZ:
        return 1000;
    case OB_SAMPLE_RATE_2_KHZ:
        return 2000;
    default:
        return 0;
    }
}

void startStream(std::shared_ptr<ob::Pipeline> pipe, std::shared_ptr<ob::Pipeline> imuPipe) {

    // Configure which streams to enable or disable for the Pipeline by creating a Config.
    std::shared_ptr<ob::Config> config    = std::make_shared<ob::Config>();
    std::shared_ptr<ob::Config> imuConfig = std::make_shared<ob::Config>();

    // Enumerate and config all sensors.
    auto device = pipe->getDevice();
    // Disable auto exposure
    device->setBoolProperty(OB_PROP_DEPTH_AUTO_EXPOSURE_BOOL, false);
    device->setBoolProperty(OB_PROP_COLOR_AUTO_EXPOSURE_BOOL, false);
    device->setBoolProperty(OB_PROP_IR_AUTO_EXPOSURE_BOOL, false);

    // Get sensor list from device.
    auto sensorList = device->getSensorList();

    for(uint32_t i = 0; i < sensorList->getCount(); i++) {
        // Get sensor type.
        auto sensorType = sensorList->getSensorType(i);

        // exclude gyro and accel sensors.
        if(sensorType == OB_SENSOR_GYRO || sensorType == OB_SENSOR_ACCEL) {
            imuConfig->enableStream(sensorType);
            continue;
        }

        // enable the stream.
        config->enableStream(sensorType);
    }

    // Start the pipeline with config
    pipe->start(config, [&](std::shared_ptr<ob::FrameSet> frameSet) {
        std::lock_guard<std::mutex> lock(frameMutex);
        frameSetQueue.push(frameSet);
        frameCv.notify_all();
    });

    imuPipe->start(imuConfig, [&](std::shared_ptr<ob::FrameSet> frameSet) {
        std::lock_guard<std::mutex> lock(imuFrameMutex);
        imuFrameSetQueue.push(frameSet);
        imuFrameCv.notify_all();
    });
}

void stopStream(std::shared_ptr<ob::Pipeline> pipe, std::shared_ptr<ob::Pipeline> imuPipe) {
    // Stop the pipeline
    pipe->stop();
    imuPipe->stop();

    while(!frameSetQueue.empty()) {
        frameSetQueue.pop();
    }

    while(!imuFrameSetQueue.empty()) {
        imuFrameSetQueue.pop();
    }
}

void createCSVFile(std::shared_ptr<ob::Pipeline> pipe, std::shared_ptr<ob::Pipeline> imuPipe) {
    auto timeStamp  = ob_smpl::getFormatTimestamp();
    auto device     = pipe->getDevice();
    auto deviceInfo = device->getDeviceInfo();

    auto colorProfile   = pipe->getStreamProfileList(OB_SENSOR_COLOR)->getVideoStreamProfile();
    auto depthProfile   = pipe->getStreamProfileList(OB_SENSOR_DEPTH)->getVideoStreamProfile();
    auto leftIrProfile  = pipe->getStreamProfileList(OB_SENSOR_IR_LEFT)->getVideoStreamProfile();
    auto rightIrProfile = pipe->getStreamProfileList(OB_SENSOR_IR_RIGHT)->getVideoStreamProfile();
    auto accelProfile   = imuPipe->getStreamProfileList(OB_SENSOR_ACCEL)->getAccelStreamProfile(OB_ACCEL_FS_UNKNOWN, OB_SAMPLE_RATE_UNKNOWN);
    auto gyroProfile    = imuPipe->getStreamProfileList(OB_SENSOR_GYRO)->getGyroStreamProfile(OB_GYRO_FS_UNKNOWN, OB_SAMPLE_RATE_UNKNOWN);

    auto formatFilePath = [&](const std::string &dir, const std::string &sensor, std::shared_ptr<ob::VideoStreamProfile> profile) {
        auto path = dir + deviceInfo->getName() + "_" + deviceInfo->getSerialNumber() + "_" + sensor + "_" + std::to_string(profile->getWidth()) + "x"
                    + std::to_string(profile->getHeight()) + "_" + std::to_string(profile->getFps()) + "fps_" + timeStamp + ".csv";
        return path;
    };

    // Create and initialize a CSV file
    std::string dir = "./output";
    ob_smpl::mkDirs(dir.c_str());
    dir += "/";
    std::string frameRatePath = dir + deviceInfo->getName() + "_" + deviceInfo->getSerialNumber() + "_AverageFrameRate_" + timeStamp + ".csv";
    std::string colorPath     = formatFilePath(dir, "Color", colorProfile);
    std::string depthPath     = formatFilePath(dir, "Depth", depthProfile);
    std::string leftIrPath    = formatFilePath(dir, "IR_Left", leftIrProfile);
    std::string rightIrPath   = formatFilePath(dir, "IR_Right", rightIrProfile);
    std::string accelPath     = dir + deviceInfo->getName() + "_" + deviceInfo->getSerialNumber() + "_Accel_"
                            + std::to_string(getSampleRate(accelProfile->sampleRate())) + "Hz_" + timeStamp + ".csv";
    std::string gyroPath = dir + deviceInfo->getName() + "_" + deviceInfo->getSerialNumber() + "_Gyro_"
                           + std::to_string(getSampleRate(gyroProfile->sampleRate())) + "Hz_" + timeStamp + ".csv";

    frameRateOutfile.open(frameRatePath);
    if(frameRateOutfile.is_open()) {
        frameRateOutfile.clear();
        frameRateOutfile << "Color,Depth,IR_Left,IR_Right,Accel,Gyro" << std::endl;
    }

    auto header = "Number,systemTimeStampUs,globalTimeStampUs,timeStampUs,indexDiff,globalTimeStampUsDiff,timeStampUsDiff";
    colorOutfile.open(colorPath);
    if(colorOutfile.is_open()) {
        colorOutfile.clear();
        colorOutfile << header << std::endl;
    }

    depthOutfile.open(depthPath);
    if(depthOutfile.is_open()) {
        depthOutfile.clear();
        depthOutfile << header << std::endl;
    }

    leftIrOutfile.open(leftIrPath);
    if(leftIrOutfile.is_open()) {
        leftIrOutfile.clear();
        leftIrOutfile << header << std::endl;
    }

    rightIrOutfile.open(rightIrPath);
    if(rightIrOutfile.is_open()) {
        rightIrOutfile.clear();
        rightIrOutfile << header << std::endl;
    }

    accelOutfile.open(accelPath);
    if(accelOutfile.is_open()) {
        accelOutfile.clear();
        accelOutfile << header << std::endl;
    }

    gyroOutfile.open(gyroPath);
    if(gyroOutfile.is_open()) {
        gyroOutfile.clear();
        gyroOutfile << header << std::endl;
    }
}

static void printUsage(void) {
    std::cout << "Usage: timestamp_tracker [-t <minutes>]\n\n";
    std::cout << "Optional arguments:\n";
    std::cout << "  -t, --time <minutes>    Maximum recording duration in minutes (default: 30 minutes)\n";
}

bool parseCommandLine(int argc, char *argv[], int &minute) {

    auto parseInt = [](const std::string &str, int &value) -> bool {
        try {
            size_t pos;
            int    parsed = std::stoi(str, &pos);
            if(pos != str.length())
                return false;  // Trailing characters
            value = parsed;
            return true;
        }
        catch(...) {
            return false;
        }
    };

    for(int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if((arg == "-t" || arg == "--time") && i + 1 < argc) {
            int val;
            if(parseInt(argv[++i], val) && val > 0) {
                minute = val;
            }
            else {
                std::cerr << "Error: Invalid recording duration. Range: 1~30.\n";
                printUsage();
                return false;
            }
        }
        else {
            std::cerr << "Unknown or incomplete argument: " << arg << "\n";
            printUsage();
            return false;
        }
    }
    return true;
}

int main(int argc, char* argv[]) try {
    int minutes = 30;
    if(!parseCommandLine(argc, argv, minutes)) {
        return 1;
    }

    // Create a context.
    ob::Context ctx;
    ctx.enableDeviceClockSync(60000);

    // Create a pipeline with default device.
    std::shared_ptr<ob::Pipeline> pipe    = std::make_shared<ob::Pipeline>();
    auto                          device  = pipe->getDevice();
    std::shared_ptr<ob::Pipeline> imuPipe = std::make_shared<ob::Pipeline>(device);

    // sync time
    device->timerSyncWithHost();

    // start stream
    startStream(pipe, imuPipe);
    std::cout << "Streams have been started. Press 'ESC' key to stop the pipeline and exit the program." << std::endl;

    auto startTime   = ob_smpl::getNowTimesMs();
    auto maxDuration = startTime + minutes * 60 * 1000;

    createCSVFile(pipe, imuPipe);

    std::atomic_bool isStopStream(false);
    std::mutex       frameCountMutex;
    uint64_t         colorCount   = 0;
    uint64_t         depthCount   = 0;
    uint64_t         leftIRCount  = 0;
    uint64_t         rightIRCount = 0;

    auto                  videoFrameThread = std::thread([&] {
        // Record the timestamp of the previous frame
        PreFrameTimeStamp preColorFrame;
        PreFrameTimeStamp preDepthFrame;
        PreFrameTimeStamp preLeftIrFrame;
        PreFrameTimeStamp preRightIrFrame;

        while(!isStopStream) {
            std::shared_ptr<ob::FrameSet> frameset = nullptr;
            {
                std::unique_lock<std::mutex> lock(frameMutex);
                frameCv.wait_for(lock, std::chrono::milliseconds(100), [&] { return isStopStream || !frameSetQueue.empty(); });
                if(isStopStream) {
                    break;
                }
                if(frameSetQueue.empty()) {
                    continue;
                }
                frameset = frameSetQueue.front();
                frameSetQueue.pop();
            }

            auto colorFrame = frameset->colorFrame();
            if(colorFrame) {
                auto     index           = colorFrame->index();
                auto     systemTimeStamp = colorFrame->systemTimeStampUs();
                auto     globalTimestamp = colorFrame->globalTimeStampUs();
                auto     devTimestamp    = colorFrame->timeStampUs();

                if(preColorFrame.first) {
                    // the first frame
                    colorOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preColorFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preColorFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preColorFrame.preTimeStamp;

                    colorOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                 << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preColorFrame.first              = false;
                preColorFrame.frameIndex         = index;
                preColorFrame.preGlobalTimeStamp = globalTimestamp;
                preColorFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++colorCount;
            }

            auto depthFrame = frameset->depthFrame();
            if(depthFrame) {
                auto index           = depthFrame->index();
                auto systemTimeStamp = depthFrame->systemTimeStampUs();
                auto globalTimestamp = depthFrame->globalTimeStampUs();
                auto devTimestamp    = depthFrame->timeStampUs();

                if(preDepthFrame.first) {
                    // the first frame
                    depthOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preDepthFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preDepthFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preDepthFrame.preTimeStamp;

                    depthOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                 << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preDepthFrame.first              = false;
                preDepthFrame.frameIndex         = index;
                preDepthFrame.preGlobalTimeStamp = globalTimestamp;
                preDepthFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++depthCount;
            }

            auto leftIrFrame = frameset->getFrame(OB_FRAME_IR_LEFT);
            if(leftIrFrame) {
                auto     index                    = leftIrFrame->index();
                auto     systemTimeStamp          = leftIrFrame->systemTimeStampUs();
                auto     globalTimestamp          = leftIrFrame->globalTimeStampUs();
                auto     devTimestamp             = leftIrFrame->timeStampUs();

                if(preLeftIrFrame.first) {
                    // the first frame
                    leftIrOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preLeftIrFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preLeftIrFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preLeftIrFrame.preTimeStamp;

                    leftIrOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                  << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preLeftIrFrame.first              = false;
                preLeftIrFrame.frameIndex         = index;
                preLeftIrFrame.preGlobalTimeStamp = globalTimestamp;
                preLeftIrFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++leftIRCount;
            }

            auto rightIrFrame = frameset->getFrame(OB_FRAME_IR_RIGHT);
            if(rightIrFrame) {
                auto index           = rightIrFrame->index();
                auto systemTimeStamp = rightIrFrame->systemTimeStampUs();
                auto globalTimestamp = rightIrFrame->globalTimeStampUs();
                auto devTimestamp    = rightIrFrame->timeStampUs();

                if(preRightIrFrame.first) {
                    // the first frame
                    rightIrOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preRightIrFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preRightIrFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preRightIrFrame.preTimeStamp;

                    rightIrOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                   << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preRightIrFrame.first              = false;
                preRightIrFrame.frameIndex         = index;
                preRightIrFrame.preGlobalTimeStamp = globalTimestamp;
                preRightIrFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++rightIRCount;
            }
        }
    });

    uint64_t accelCount = 0;
    uint64_t gyroCount  = 0;

    auto                  imuFrameThread = std::thread([&] {
        // Record the timestamp of the previous frame
        PreFrameTimeStamp preAccelFrame;
        PreFrameTimeStamp preGyroFrame;

        while(!isStopStream) {
            std::shared_ptr<ob::FrameSet> imuFrameset = nullptr;
            {
                std::unique_lock<std::mutex> lock(imuFrameMutex);
                imuFrameCv.wait_for(lock, std::chrono::milliseconds(100), [&] { return isStopStream || !imuFrameSetQueue.empty(); });
                if(imuFrameSetQueue.empty()) {
                    continue;
                }
                imuFrameset = imuFrameSetQueue.front();
                imuFrameSetQueue.pop();
            }

            auto accelFrame = imuFrameset->getFrame(OB_FRAME_ACCEL);
            if(accelFrame) {
                auto     index                   = accelFrame->index();
                auto     systemTimeStamp         = accelFrame->systemTimeStampUs();
                auto     globalTimestamp         = accelFrame->globalTimeStampUs();
                auto     devTimestamp            = accelFrame->timeStampUs();

                if(preAccelFrame.first) {
                    // the first frame
                    accelOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preAccelFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preAccelFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preAccelFrame.preTimeStamp;

                    accelOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                 << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preAccelFrame.first              = false;
                preAccelFrame.frameIndex         = index;
                preAccelFrame.preGlobalTimeStamp = globalTimestamp;
                preAccelFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++accelCount;
            }

            auto gyroFrame = imuFrameset->getFrame(OB_FRAME_GYRO);
            if(gyroFrame) {
                auto index           = gyroFrame->index();
                auto systemTimeStamp = gyroFrame->systemTimeStampUs();
                auto globalTimestamp = gyroFrame->globalTimeStampUs();
                auto devTimestamp    = gyroFrame->timeStampUs();

                if(preGyroFrame.first) {
                    // the first frame
                    gyroOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << ",,," << std::endl;
                }
                else {
                    uint64_t indexDiff           = index - preGyroFrame.frameIndex;
                    uint64_t globalTimestampDiff = globalTimestamp - preGyroFrame.preGlobalTimeStamp;
                    uint64_t devTimestampDiff    = devTimestamp - preGyroFrame.preTimeStamp;

                    gyroOutfile << index << "," << systemTimeStamp << "," << globalTimestamp << "," << devTimestamp << "," << indexDiff << ","
                                 << globalTimestampDiff << "," << devTimestampDiff << std::endl;
                }
                preGyroFrame.first              = false;
                preGyroFrame.frameIndex         = index;
                preGyroFrame.preGlobalTimeStamp = globalTimestamp;
                preGyroFrame.preTimeStamp       = devTimestamp;

                std::lock_guard<std::mutex> lock(frameCountMutex);
                ++gyroCount;
            }
        }
    });

    while(true) {
        if(ob_smpl::waitForKeyPressed(1000) == ESC_KEY) {
            isStopStream = true;
            break;
        }
        auto currentTime = ob_smpl::getNowTimesMs();
        if(currentTime >= maxDuration) {
            isStopStream = true;
            std::cout << "Reaching maximum duration. Stop stream and exit now." << std::endl;
            break;
        }
        uint64_t duration = currentTime - startTime;
        if(duration > 0) {

            std::ostringstream          oss;
            {
                std::lock_guard<std::mutex> lock(frameCountMutex);

                float colorRate   = colorCount / (duration / 1000.0f);
                float depthRate   = depthCount / (duration / 1000.0f);
                float leftIrRate  = leftIRCount / (duration / 1000.0f);
                float rightIrRate = rightIRCount / (duration / 1000.0f);
                float accelRate   = accelCount / (duration / 1000.0f);
                float gyroRate    = gyroCount / (duration / 1000.0f);

                colorCount   = 0;
                depthCount   = 0;
                leftIRCount  = 0;
                rightIRCount = 0;
                accelCount   = 0;
                gyroCount    = 0;

                oss << std::fixed << std::setprecision(2) << std::showpoint;
                oss << colorRate << "," << depthRate << "," << leftIrRate << "," << rightIrRate << "," << accelRate << "," << gyroRate << std::endl;
            }
            frameRateOutfile << oss.str();
        }
        startTime = currentTime;
    }

    std::cout << "Stop streams now." << std::endl;

    if(videoFrameThread.joinable()) {
        videoFrameThread.join();
    }
    if(imuFrameThread.joinable()) {
        imuFrameThread.join();
    }

    frameRateOutfile.close();
    colorOutfile.close();
    depthOutfile.close();
    leftIrOutfile.close();
    rightIrOutfile.close();
    accelOutfile.close();
    gyroOutfile.close();
    // Stop the Pipeline, no frame data will be generated.
    stopStream(pipe, imuPipe);

    return 0;
}
catch(ob::Error &e) {
    std::cerr << "function:" << e.getFunction() << "\nargs:" << e.getArgs() << "\nmessage:" << e.what() << "\ntype:" << e.getExceptionType() << std::endl;
    std::cout << "\nPress any key to exit.";
    ob_smpl::waitForKeyPressed();
    exit(EXIT_FAILURE);
}
